import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import { hydrate, seedIfEmpty } from './store'
import './index.css'

hydrate().then(() => {
  seedIfEmpty()
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  )
})

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {})
  })
}
